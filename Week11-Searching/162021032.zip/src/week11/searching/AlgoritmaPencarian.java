/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week11.searching;

/**
 *
 * @author Davit
 */
public class AlgoritmaPencarian {
    public static int linearSearch(int arr[], int value){
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == value) {
                System.out.println("Elemen "+value+ " ditemukan pada index: "+i);
                return i;
            }
        }
        System.out.println("Element "+value+" tidak ditemukan");
        return -1;
    }
    
    public static int binarySearch(int arr[], int value){
        int low = 0;
        int high = arr.length-1;
        int mid = (low +high)/2;
        while(arr[mid] != value && low <= high){
            if (value < arr[mid]) {
                high = mid-1;
            } else {
                low = mid +1;
            }
            mid = (low +mid )/2;
        }
        if (arr[mid] == value) {
            System.out.println("ditemukan");
            return mid;
        } else {
            System.out.println("tidak ditemukan");
            return -1;
        }
    }
}
