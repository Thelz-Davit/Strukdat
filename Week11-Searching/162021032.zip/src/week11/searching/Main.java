/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package week11.searching;

/**
 *
 * @author Davit
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] arrNumber = {1,2,3,4,5};
        AlgoritmaPencarian searching = new AlgoritmaPencarian();
        searching.linearSearch(arrNumber, 5);
        
        searching.binarySearch(arrNumber, 3);
    }
    
}
